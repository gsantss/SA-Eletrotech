<?php

session_start();

require_once('../config/Conexao.php');
require_once('../dao/AgendamentoDao.php');
require_once('../model/Agendamento.php');

$agendamento = new Agendamento();
$agendamentodao = new AgendamentoDao();

$id = $_SESSION['user_session'];

$dados = filter_input_array(INPUT_POST);

if (isset($_POST['cadastrar'])) {

    $agendamento->setIdCliente($id);
    $agendamento->setHorario($dados['horario']);
    $agendamento->setTipo($dados['tipo']);

    echo $agendamento->getIdCliente();

    if ($agendamentodao->criar($agendamento)) {
        echo "<script>
                alert('Agendamento Cadastrado com Sucesso!!');
                location.href = '../views/agendamento/agendamentos.php';
              </script>";
    }

}

?>