<?php 

require_once('../config/Conexao.php');
require_once('../dao/ClienteDao.php');
require_once('../model/Cliente.php');

$cliente = new Cliente();
$clientedao = new ClienteDao();

$dados = filter_input_array(INPUT_POST);

if(isset($_POST['btlogin'])) {

	$cliente->setEmail($dados['email']);
	$cliente->setSenha($dados['senha']); 

    $clientedao->login($cliente);

	if($clientedao->login($cliente)) {

     echo "<script>
            alert('Usuário logado com Sucesso!!');
            location.href = '../';
           </script>";

	} else {
        echo "<script>
                alert('Acesso inválido! login ou senha incorretos!');
                location.href = '../views/login/';
            </script>";
	}	

// se a requisição for logout      
} else if (isset($_POST['cadastrar'])) {

    $cliente->setNome($dados['nome']);
    $cliente->setCpf($dados['cpf']);
    $cliente->setTelefone($dados['telefone']);
    $cliente->setEmail($dados['email']);
    $cliente->setRua($dados['rua']);
    $cliente->setBairro($dados['bairro']);
    $cliente->setCidade($dados['cidade']);
    $cliente->setEstado($dados['estado']);
    $cliente->setNumero($dados['numero']);
    $cliente->setComplemento($dados['complemento']);
    $cliente->setSenha($dados['senha']);

    if ($clientedao->criar($cliente)) {
        echo "<script>
                alert('Usuário Cadastrado com Sucesso!!');
                location.href = '../';
              </script>";
    }

} else if (isset($_POST['alterar'])) {

    $cliente->setId($dados['id_alter']);
    $cliente->setNome($dados['nome']);
    $cliente->setCpf($dados['cpf']);
    $cliente->setTelefone($dados['telefone']);
    $cliente->setEmail($dados['email']);
    $cliente->setRua($dados['rua']);
    $cliente->setBairro($dados['bairro']);
    $cliente->setCidade($dados['cidade']);
    $cliente->setEstado($dados['estado']);
    $cliente->setNumero($dados['numero']);
    $cliente->setComplemento($dados['complemento']);
    $cliente->setSenha($dados['senha']);

    if ($clientedao->alterar($cliente)) {
        echo "<script>
                  alert('Cliente Alterado com Sucesso!!');
              </script>";
        header('Location: ../');
    }

} else if (isset($_POST['excluir'])) {

    $cliente->setId($_POST['id_del']);

    if ($clientedao->excluir($cliente)) {
        echo "<script>
                  alert('Cliente Deletado com Sucesso!!');
              </script>";
        $clientedao->logout();
        header('Location: ../');
    }

} else if (isset($_POST['free'])) {

    $cliente->setId($_POST['idcliente']);
    $cliente->setPlano("Free");

    if ($clientedao->addplano($cliente->getId(), $cliente->getPlano())) {
        echo "<script>
                  alert('Plano Escolhido com Sucesso!!');
              </script>";
        header('Location: ../');        
    }

} else if (isset($_POST['black'])) {

    header('Location: ../views/plano/pagamentop.php');

} else if (isset($_POST['basic'])) {

    header('Location: ../views/plano/pagamentob.php');

}  else if (isset($_POST['basicp'])) {

    $cliente->setId($_POST['idcliente']);
    $cliente->setPlano("Premium Basic");

    if ($clientedao->addplano($cliente->getId(), $cliente->getPlano())) {
        echo "<script>
                  alert('Plano Escolhido com Sucesso!!');
              </script>";
        header('Location: ../');        
    }

}  else if (isset($_POST['blackp'])) {

    $cliente->setId($_POST['idcliente']);
    $cliente->setPlano("Premium Black");

    if ($clientedao->addplano($cliente->getId(), $cliente->getPlano())) {
        echo "<script>
                  alert('Plano Escolhido com Sucesso!!');
              </script>";
        header('Location: ../');        
    }

} else if (isset($_POST['desmarcar'])) {

    $cliente->setId($_POST['idcliente']);

    if ($clientedao->excluiragendamento($cliente)) {
        header('Location: ../views/agendamento/agendamentos.php');
    }

} else if (isset($_POST['logout'])) {
    $clientedao->logout();
}

?>