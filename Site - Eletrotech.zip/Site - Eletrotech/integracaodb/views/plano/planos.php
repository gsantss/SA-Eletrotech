<?php
session_start();

require_once('../../config/Conexao.php');
require_once('../../dao/AgendamentoDao.php');
require_once('../../model/Agendamento.php');
require_once('../../dao/ClienteDao.php');
require_once('../../model/Cliente.php');

Conexao::getConexao();

$agendamentodao = new AgendamentoDao();
$agendamento = new Agendamento();
$clientedao = new ClienteDao();
$cliente = new Cliente();

$id = $_SESSION['user_session'];

$login = new ClienteDao();

if(!$login->checkLogin()) {
    header("Location: views/login");
} 
//else { session_destroy(); }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../Normalize.css"/>
    <link rel="stylesheet" type="text/css" href="acessoClienteSemPlano.css" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>Acesso Cliente Free</title>
</head>
<body>
    
    <section id="navbar">
        <div id="nav-content">
            <div id="space"></div>
            <div id="brand"><a href="../../">EletroTech</a></div>
            <div id="registrar"><button id="btn-login" onclick="window.location = '../agendamento/agendamentos.php'">Agendamentos</button></div> 
        </div> 
    </section>

    <form action="../../controller/ClienteController.php" method="post">
    <input type="hidden" name="idcliente" id="idcliente" value="<?= $id ?>">
    <section id="content-space">
        <div id="content">
            <div id="title-content">Escolha seu Plano</div>
            <div id="block-content">
                <button type="submit" class="button-block" name="black" id="black">
                    <div class="block">
                        <div class="block-title1">Premium Black</div>
                        <div class="block-description1">Pacote inclui:<br> 
                           <ul>
                                <li>7 visitas de Avaliação</li>
                                <li>7 visitas de Manutenção</li>
                                <li>Suporte especializado</li>
                                <li>Prioridade de Horários</li>
                           </ul>
                        </div>
                        <div class="block-price1">R$ 1999,99</div>
                    </div>
                </button>
                <button type="submit" class="button-block" name="basic" id="basic">
                    <div class="block">
                        <div class="block-title">Premium Basic</div>
                        <div class="block-description">Pacote inclui:<br> 
                           <ul>
                                <li>2 visitas de Avaliação</li>
                                <li>2 visitas de Manutenção</li>
                                <li>Suporte especializado</li>
                                <li>Prioridade de Horários</li>
                           </ul>
                        </div>
                        <div class="block-price">R$ 499,99</div>
                    </div>
                </button>
                <button type="submit" class="button-block" name="free" id="free">
                    <div class="block">
                        <div class="block-title">Free</div>
                        <div class="block-description">Pacote inclui:<br> 
                           <ul>
                                <li>Acesso a Área de Agendamentos</li>
                                <li>3° na lista de Prioridade</li>
                                <li>Suporte especializado</li>
                                <li>Preferência de Horários</li>
                           </ul>
                        </div>
                        <div class="block-price">R$ 0,00</div>
                    </div>
                </button>
            </div>
            <div id="desc-content">Aviso: Caso o cliente opite por não escolher um plano, ele terá que pagar um valor fixo de R$150,00 para Visitas de Avaliação e R$300,00 para as Visitas de Manutenção/Conserto.</div>
        </div>
    </section>
    </form>

    <section id="footer">
        <div id="content-footer">
            <div id="block-footer-mid">
                <div class="title-block">Contato</div>
                <div class="description-block">Telefone: (31) 99690-5648<br>
                    Email: EletroTechSolutions@contato.com</div>
            </div>
            <div class="block-footer">
                <div class="title-block">Endereço</div>
                <div class="description-block">R. Rio de Janeiro, 471 - Centro, Belo Horizonte - MG, 30160-440</div>
            </div>
        </div>
    </section>

</body>
</html>