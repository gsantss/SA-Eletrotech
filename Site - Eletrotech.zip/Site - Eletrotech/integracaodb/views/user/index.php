<?php
session_start();

require_once('../../config/Conexao.php');
require_once('../../dao/AgendamentoDao.php');
require_once('../../model/Agendamento.php');
require_once('../../dao/ClienteDao.php');
require_once('../../model/Cliente.php');

Conexao::getConexao();

$agendamentodao = new AgendamentoDao();
$agendamento = new Agendamento();
$clientedao = new ClienteDao();
$cliente = new Cliente();

$login = new ClienteDao();

if(!$login->checkLogin()) {
    header("Location: views/login");
} 
//else { session_destroy(); }

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Tela Inicial </title>
    <link rel="stylesheet" href="index.css">
    <script src="index.js"></script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>

<body>




    <header>

        <section id="navbar">
            <div id="nav-content">
                <div id="space"> 

                <div id="logout"><form action="../../controller/ClienteController.php" method="post"><button type="submit" name="logout" id="btn-logout"> Logout </button></form></div>


                </div>
                <div id="brand"><a href="../../">EletroTech</a></div>
                <div id="registrar"><button id="btn-login" onclick="window.location = '../agendamento/agendamentos.php'">Agendamentos</button></div>
            </div>
        </section>

    </header>



    <main>


        <div id="myCarousel" class="carousel t-carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">

                    <!-- <article id="art1">

                        <section id="sec2" class="container">

                            <section id="sec3">


                                <p> Está com problemas na parte elétrica da sua casa ou empresa? </p>

                            </section>

                            <section id="sec4" class="container">

                                <p> Agende uma visita para um de nossos técnicos resolver o problema! </p>

                            </section>

                        </section>

                    </article>


                    <article id="art2" class="container">

                        <button id="btn2">

                            Realizar Agendamento

                        </button>


                    </article> -->

                    <img src="img/teste1.png" alt="Los Angeles">


                </div>

                <div class="item">

                    <article id="art1">

                        <section id="sec2" class="container">

                            <section id="sec3">


                                <p> Está com problemas na parte elétrica da sua casa ou empresa? </p>

                            </section>

                            <section id="sec4" class="container">

                                <p> Agende uma visita para um de nossos técnicos resolver o problema! </p>

                            </section>

                        </section>

                    </article>


                    <article id="art2" class="container">

                        <button id="btn2" onclick="window.location = '../agendamento/addagendamento.php'">

                            Realizar Agendamento

                        </button>


                    </article>
                    <img src="img/teste2.png" alt="Chicago">
                </div>

                <div class="item">

                    <article id="art7">

                        <section id="sec2" class="container">

                            <section id="sec11">


                                <p> SOBRE NÓS </p>

                            </section>

                            <section id="sec12" class="container">

                                <p> A Eletro Tech Solutions é uma empresa de prestação de serviços na parte elétrica, atendendo casas e empresas. </p>

                            </section>

                        </section>

                    </article>

                    <img src="img/teste3.png" alt="New York">
                </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>


        <article id="art3">

            <section id="sec5" class="container">

                <p> Tipos de visita </p>

            </section>

        </article>


        <article id="art4">

            <section id="sec6">

                <section id="c1" class="container">
                    <p> Visita de Avaliação </p>
                </section>
                <p> Nosso técnico é enviado realizar uma avaliação do problema em questão e traçar um tragetória de
                    manutenção </p>

            </section>

            <section id="sec7">

                <section id="c2" class="container">
                    <p> Visita de Manutenção </p>
                </section>
                <p> Apenas após realizar uma visita de avaliação, nosso técnico é enviado para realizar uma Visita de
                    manutenção onde ele ira solucionar o problema </p>

            </section>


        </article>

        <article id="art5">

            <section id="sec8" class="container">

                <button onclick="window.location = '../plano/planos.php'" id="btn-plano"> Planos de serviço </button>


            </section>

        </article>

        <!-- <article id="art6">


            <section id="sec9">

                <section id="sc1">

                    <section id="c3" class="container">
                        <p> Premium Black </p>
                    </section>


                </section>


                <section id="sc2">

                    <section id="cc1">
                        <ul> Pacote inclui:

                            <li> 7 visitas de Avaliação </li>
                            <li> 7 visitas de Manutenção </li>
                            <li> Suporte especializado </li>
                            <li> Preferência de Horários </li>

                        </ul>
                    </section>

                </section>


                <section id="sc3">

                    <section id="c4" class="container">
                        <p> R$ 1999,99/Mês </p>
                    </section>


                </section>



            </section>


            <section id="sec10">

                <section id="sc4">

                    <section id="c5" class="container">
                        <p> Premium Basic </p>
                    </section>


                </section>


                <section id="sc5">

                    <section id="cc2">
                        <ul> Pacote inclui:

                            <li> 2 visitas de Avaliação </li>

                            <li> 2 visitas de Manutenção </li>

                        </ul>
                    </section>

                </section>


                <section id="sc6">

                    <section id="c6" class="container">
                        <p> R$ 500,99/Mês </p>
                    </section>


                </section>



            </section>

        </article> -->

        <section id="footer">
            <div id="content-footer">
                
                <div class="block-footer">
                    <div class="title-block">Contato</div>
                    <div class="description-block">Telefone: (31) 99690-5648<br>
                        Email: EletroTechSolutions@contato.com</div>
                </div>
                <div class="block-footer">
                    <div class="title-block">Endereço</div>
                    <div class="description-block">R. Rio de Janeiro, 471 - Centro, Belo Horizonte - MG, 30160-440</div>
                </div>
            </div>
        </section>
    </main>


</body>

</html>