<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../Normalize.css"/>
    <link rel="stylesheet" type="text/css" href="criarConta.css" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>Criar Conta</title>
</head>
<body>
    <section id="navbar">
        <div id="nav-content">
            <div id="space"></div>
            <div id="brand"><a href="../../">EletroTech</a></div>
            <div id="registrar"><button id="btn-login" onclick="window.location = '../login'">Login</button></div> 
        </div> 
    </section>

    <section id="login"> 
        <form action="../../controller/ClienteController.php" method="post" name="cad" id="content-login">
            <div id="title-login">Cadastro</div>
            <!-- <div class="fields-login-double">
                <div class="camp-double1">
                    <label for="inputPlano" class="form-label">Plano Escolhido:</label>
                    <select class="form-select" id="inputPlano">
                        <option selected value="1" id="premiumBlack">Premium Black</option>
                        <option value="2" id="premiumBasic">Premium Basic</option>
                      </select>
                </div>
                <div class="camp-double">
                    <label for="inputValor" class="form-label">Valor:</label>
                    <input type="valor" disabled class="form-control"  value="R$ 1999,99" id="inputValor">
                </div>
                
            </div> -->

            <div class="fields-login">
                <label for="nome" class="form-label" >Nome Completo:</label>
                <input type="text" required class="form-control" id="nome" name="nome">
            </div>
            <div class="fields-login">
                <label for="cpf" class="form-label" >CPF:</label>
                <input type="text" required class="form-control" id="cpf" name="cpf">
            </div>
            <div class="fields-login">
                <label for="email" class="form-label" >Email:</label>
                <input type="email" required class="form-control" id="email" name="email">
            </div>
            <div class="fields-login">
                <label for="telefone" class="form-label" >Telefone:</label>
                <input type="tel" required class="form-control" id="telefone" name="telefone">
            </div>
            <div class="fields-login-double">
                <div class="camp-double1">
                    <label for="rua" class="form-label">Rua:</label>
                    <input type="text" required class="form-control" id="rua" name="rua" min="2023-02">
                </div>
                <div class="camp-double">
                    <label for="numero" class="form-label">Número:</label>
                    <input type="number" required class="form-control" id="numero" name="numero">
                </div>
            </div>
            <div class="fields-login-double">
                <div class="camp-double">
                    <label for="bairro" class="form-label">Bairro:</label>
                    <input type="text" required class="form-control" id="bairro" name="bairro" min="2023-02">
                </div>
                <div class="camp-double">
                    <label for="cidade" class="form-label">Cidade:</label>
                    <input type="text" required class="form-control" id="cidade" name="cidade">
                </div>
            </div>
            <div class="fields-login-double">
                <div class="camp-double">
                    <label for="estado" class="form-label">Estado:</label>
                    <input type="text" required class="form-control" id="estado" name="estado">
                </div>
                <div class="camp-double">
                    <label for="complemento" class="form-label">Complemento:</label>
                    <input type="text" class="form-control" id="complemento" name="complemento" min="2023-02">
                </div>
            </div>
            <div class="fields-login">
                <label for="senha" class="form-label" >Senha:</label>
                <input type="password" required class="form-control" id="senha" name="senha">
            </div>
            <div id="fields-buttons">
                <button type="submit" class="btn" id="cadastrar" name="cadastrar">Criar Conta</button> 
            </div>
        </form>
    </section>

    <section id="footer">
        <div id="content-footer">
            <div class="block-footer">
                <div class="title-block">Contato</div>
                <div class="description-block">Telefone: (31) 99690-5648<br>
                    Email: EletroTechSolutions@contato.com</div>
            </div>
            <div class="block-footer">
                <div class="title-block">Endereço</div>
                <div class="description-block">R. Rio de Janeiro, 471 - Centro, Belo Horizonte - MG, 30160-440</div>
            </div>
        </div>
    </section>

</body>
</html>