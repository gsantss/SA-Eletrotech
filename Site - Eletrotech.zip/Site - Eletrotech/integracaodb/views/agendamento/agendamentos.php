<?php 

session_start();

require_once('../../config/Conexao.php');
require_once('../../dao/AgendamentoDao.php');
require_once('../../model/Agendamento.php');
require_once('../../dao/ClienteDao.php');
require_once('../../model/Cliente.php');

//instancia as classes
$usuario = new Cliente();
$userdao = new ClienteDao();
$agendamento = new Agendamento();
$agendamentodao = new AgendamentoDao();

$login = new ClienteDao();

$id = $_SESSION['user_session'];

if(!$login->checkLogin()) {
    header("Location: ../login");
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Pagamento sem plano </title>
    <link rel="stylesheet" href="pagamentosp.css">
    <script src="pagamentosp.js"></script>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script>

            function deletar() {
                ok = confirm("Deseja realmente excluir esta conta?");
                if(ok){
                    return true;
                } else {
                    return false;
                }
            }
            
            function desmarcar() {
                op = confirm("Deseja realmente desmarcar este Agendamento?");
                if(op){
                    return true;
                } else {
                    return false;
                }
            }

        </script>
</head>

<body>

    <header>

        <section id="navbar">
            <div id="nav-content">
                <div id="space"></div> 
                <div id="brand"><a href="../../">EletroTech</a></div>
                <button type="button" id="myBtn" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"> User </button>            
                </div> 
       

                <!-- Modal -->
                <div id="myModal" class="modal t-modal fade" role="dialog">
                    <div class="modal-dialog">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <?php foreach ($userdao->listar($id) as $usuario) : ?>
                                <section id="md1">
                                    <p id="p1"> Informações Básicas </p>
                                    <p> Nome: <?= $usuario->getNome() ?> </p>
                                    <p> CPF: <?= $usuario->getCpf() ?> </p>
                                    <p> Plano: <?= $usuario->getPlano() ?> </p>

                                </section>

                                <section id="md2">

                                    <p id="p2"> Informações de contato </p>
                                    <p> Telefone: <?= $usuario->getTelefone() ?> </p>
                                    <p> Email: <?= $usuario->getEmail() ?> </p>


                                </section>

                                <section id="md3">


                                    <p id="p3"> Endereço </p>
                                    <p> Rua: <?= $usuario->getRua() ?> </p>
                                    <p> Bairro: <?= $usuario->getBairro() ?> </p>
                                    <p> Estado: <?= $usuario->getEstado() ?> </p>

                                </section>

                                <section id="md4">

                                    <p> Número: <?= $usuario->getNumero() ?> </p>
                                    <p> Cidade: <?= $usuario->getCidade() ?> </p>
                                    <p> Complemento: <?= $usuario->getComplemento() ?> </p>

                                </section>
                                <?php endforeach ?>
                            </div>
                            <div class="modal-footer">

                                <section id="md5">
                                    <form action="../../controller/ClienteController.php" method="post">

                                    <input type="hidden" id="id_del" name="id_del" value="<?= $id ?>"/>
                                    <button type="submit" id="excluir" name="excluir" onclick="return deletar()" class="btn bnt btn-danger"> Excluir conta </button>
                                    
                                    </form>
                                </section>

                                <section id="md6">

                                    <button type="button" onclick="window.location = '../../'" class="btn bnt btn-warning"> Voltar ao menu principal
                                    </button>

                                </section>

                                <section id="md7">

                                    <button type="button" onclick="window.location = '../alterar'" class="btn bnt btn-primary"> Alterar dados </button>

                                </section>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

    </header>



    <section id="sec1">

        <section id="sec2">

            <p> Meus agendamentos </p>

        </section>


        <section id="sec3">

            <button id="btn1" onclick="window.location = './addagendamento.php'"> Novo Agendamento </button>


        </section>


    </section>
    <?php foreach ($agendamentodao->listar($id) as $agendamento) : ?>
    <section id="sec4" class="container">

        <section class="sc">

        <p> Data: <br> 02/02/2023 </p>
            
        </section>


        <section class="sc">

        <p> Tipo: <br> <?= $agendamento->getTipo() ?> </p>

        </section>


        <section class="sc">

        <p> Horário: <br> <?= $agendamento->getHorario() ?>:00 </p>

        </section>


        <section class="sc">

        <p> <?php 
                if ($userdao->checkfree($id)) { 
                    if ($agendamento->getTipo() == "Manutenção") {
                        echo "Valor: <br> R$300.00";
                    } else if ($agendamento->getTipo() == "Avaliação") {
                        echo "Valor: <br> R$150.00";
                    }
                } 
            ?> 
        </p>

        </section>


        <section class="sc">


        </section>


        <section class="sc">
        <form action="../../controller/ClienteController.php" method="post">
        <input type="hidden" name="idcliente" value="<?= $id ?>">
         <button type="submit" name="desmarcar" id="btn-cancel" class="btn btn-danger" onclick="return desmarcar()"> Desmarcar </button>
        </form>
        </section>

    </section>
    <?php endforeach ?>

    <section id="footer">
        <div id="content-footer">
            <div class="block-footer">
                <div class="title-block">Contato</div>
                <div class="description-block">Telefone: (31) 99690-5648<br>
                    Email: EletroTechSolutions@contato.com</div>
            </div>
            <div class="block-footer">
                <div class="title-block">Endereço</div>
                <div class="description-block">R. Rio de Janeiro, 471 - Centro, Belo Horizonte - MG, 30160-440</div>
            </div>
        </div>
    </section>

</body>

</html>