<?php 

session_start();

require_once('../../config/Conexao.php');
require_once('../../dao/AgendamentoDao.php');
require_once('../../model/Agendamento.php');
require_once('../../dao/ClienteDao.php');
require_once('../../model/Cliente.php');

//instancia as classes
$usuario = new Cliente();
$userdao = new ClienteDao();
$agendamento = new Agendamento();
$agendamentodao = new AgendamentoDao();

$login = new ClienteDao();

$id = $_SESSION['user_session'];

if(!$login->checkLogin()) {
    header("Location: ../login");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../Normalize.css"/>
    <link rel="stylesheet" type="text/css" href="adicionarNovoAgendamento.css"/>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->

   


    <title>Novo Agendamento</title>
</head>
<body>
    <section id="navbar">
        <div id="nav-content">
            <div id="space"></div> 
            <div id="brand"><a href="../../">EletroTech</a></div>
            <div id="registrar"><button onclick="window.location = '../alterar'" id="btn-login">Perfil</button></div>
        </div> 
    </section>

    <section id="title">
        <div id="title-content">Novo Agendamento</div>
    </section>

    <form action="../../controller/AgendamentoController.php" method="post">
        <section id="agendamento">
            <div id="agendamento-content">
                <div class="agendamento-field-data">
                    <label for="inputData" class="form-label">Data:</label>
                    <input type="date" required class="form-control" disabled value="2023-02-02"id="inputData">
                </div>
                <div class="agendamento-field-hora">
                    <label for="horario" class="form-label">Horario:</label>
                    <select class="form-select" required name="horario" id="horario">
                        <option selected value=""></option>
                        <option value="8" id="h8">08:00</option>
                        <option value="10" id="premiumBlack">10:00</option>
                        <option value="14" id="premiumBasic">14:00</option>
                        <option value="16" id="premiumBasic">16:00</option>
                    </select>
                </div>
                <div class="agendamento-field-tipo">
                    <label for="tipo" class="form-label">Tipo:</label>
                    <select class="form-select" required name="tipo" id="tipo">
                        <option selected value=""></option>
                        <option value="Avaliação" id="tAvaliacao">Avaliação</option>
                        <option value="Manutenção" id="tManutencao">Manutenção</option>
                    </select>
                </div>
                <div class="agendamento-field-button">
                    <button onclick="<?= $userdao->checkplano($id) ?>" type="submit" class="btn" name="cadastrar" id="btn-novo">Cadastrar Agendamento</button>
                </div>
            </div>
        </section>    
    </form>

    <!-- data-bs-toggle="modal" data-bs-target="#popup-success" -->
    <section id="footer">
        <div id="content-footer">
            <div class="block-footer">
                <div class="title-block">Contato</div>
                <div class="description-block">Telefone: (31) 99690-5648<br>
                    Email: EletroTechSolutions@contato.com</div>
            </div>
            <div class="block-footer">
                <div class="title-block">Endereço</div>
                <div class="description-block">R. Rio de Janeiro, 471 - Centro, Belo Horizonte - MG, 30160-440</div>
            </div>
        </div>
    </section>

    <!-- MODAL SUCESSO -->
    <div class="modal fade" id="popup-success" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content" id="color-success">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">Sucesso!</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              Seu Agendamento foi registrado com sucesso!
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" id="success-btn" data-bs-dismiss="modal">Fechar</button>
              
            </div>
          </div>
        </div>
    </div>

    <!-- Modal error -->
    <div class="modal fade" id="popup-error" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content" id="color-error">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">Erro!</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              Ocorreu uma falha ao registrar seu agendamento no sistema, tente novamente ou contate o suporte!
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" id="error-btn" data-bs-dismiss="modal">Fechar</button>
              
            </div>
          </div>
        </div>
    </div>
    
    <script>
        const modal = document.getElementById("popup-error")

        const btn = document.getElementById("btn-novo")

        btn.addEventListener("click", ()=>{modal.style.display = "block"})
        
    </script>
</body>
</html>