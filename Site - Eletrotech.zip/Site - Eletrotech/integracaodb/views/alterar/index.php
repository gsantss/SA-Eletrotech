<?php 

session_start();

require_once('../../config/Conexao.php');
require_once('../../dao/ClienteDao.php');
require_once('../../model/Cliente.php');

//instancia as classes
$usuario = new Cliente();
$userdao = new ClienteDao();

$login = new ClienteDao();

$id = $_SESSION['user_session'];

if(!$login->checkLogin()) {
    header("Location: ../login");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../Normalize.css"/>
    <link rel="stylesheet" type="text/css" href="atualizarDadosCliente.css"/>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>Atualizar Dados Cliente</title>
</head>
<body>
    <section id="navbar">
        <div id="nav-content">
            <div id="space"></div> 
            <div id="brand"><a href="../../">EletroTech</a></div>
            <div id="registrar"><button id="btn-login" onclick="window.location = '../agendamento/agendamentos.php'">Agendamentos</button></div>
        </div> 
    </section>

    <?php foreach ($userdao->listar($id) as $usuario) : ?>
    <section id="login"> 
        <form action="../../controller/ClienteController.php" method="post" id="content-login">
            <div id="title-login">Editar Perfil</div>
            <!-- <div class="fields-login-double">
                <div class="camp-double1">
                    <label for="inputPlano" class="form-label">Plano Escolhido:</label>
                    <select class="form-select" id="inputPlano">
                        <option selected value="1" id="premiumBlack">Premium Black</option>
                        <option value="2" id="premiumBasic">Premium Basic</option>
                      </select>
                </div>
                <div class="camp-double">
                    <label for="inputValor" class="form-label">Valor:</label>
                    <input type="valor" disabled class="form-control"  value="R$ 1999,99" id="inputValor">
                </div>
                
            </div> -->

            <div class="fields-login">
                <input type="hidden" id="id_alter" name="id_alter" value="<?= $usuario->getID() ?>" />
                <label for="nome" class="form-label" >Nome Completo:</label>
                <input type="text" class="form-control" name="nome" value="<?= $usuario->getNome() ?>" id="nome" value="André">
            </div>
            <div class="fields-login">
                <label for="cpf" class="form-label" >CPF:</label>
                <input type="text" class="form-control" name="cpf" value="<?= $usuario->getCpf() ?>" id="cpf" value="00000000-00">
            </div>
            <div class="fields-login">
                <label for="email" class="form-label" >Email:</label>
                <input type="email" class="form-control" name="email" value="<?= $usuario->getEmail() ?>" id="email">
            </div>
            <div class="fields-login">
                <label for="telefone" class="form-label" >Telefone:</label>
                <input type="text"  class="form-control" name="telefone" value="<?= $usuario->getTelefone() ?>" id="telefone">
            </div>
            <div class="fields-login-double">
                <div class="camp-double1">
                    <label for="cep" class="form-label">Rua:</label>
                    <input type="text"  class="form-control" name="rua" value="<?= $usuario->getRua() ?>" id="cep" min="2023-02">
                </div>
                <div class="camp-double">
                    <label for="numero" class="form-label">Número:</label>
                    <input type="text" required class="form-control" name="numero" value="<?= $usuario->getNumero() ?>" id="numero">
                </div>
            </div>
            <div class="fields-login-double">
                <div class="camp-double">
                    <label for="bairro" class="form-label">Bairro:</label>
                    <input type="text"  class="form-control" name="bairro" value="<?= $usuario->getBairro() ?>" id="bairro" min="2023-02">
                </div>
                <div class="camp-double">
                    <label for="cidade" class="form-label">Cidade:</label>
                    <input type="text"  class="form-control" name="cidade" value="<?= $usuario->getCidade() ?>" id="cidade">
                </div>
            </div>
            <div class="fields-login-double">
                <div class="camp-double">
                    <label for="estado" class="form-label">Estado:</label>
                    <input type="text"  class="form-control" name="estado" value="<?= $usuario->getEstado() ?>" id="estado">
                </div>
                <div class="camp-double">
                    <label for="complemento" class="form-label">Complemento:</label>
                    <input type="text"  class="form-control" name="complemento" value="<?= $usuario->getComplemento() ?>" id="complemento" min="2023-02">
                </div>
            </div>
            <div class="fields-login">
                <label for="senha" class="form-label" >Senha:</label>
                <input type="password"  class="form-control" name="senha" value="<?= $usuario->getSenha() ?>" id="senha">
            </div>
            <div id="fields-buttons">
                <button type="submit" class="btn" name="alterar" id="btn-log">Alterar Dados</button> 
            </div>
        </form>
    </section>
    <?php endforeach ?>

    <section id="footer">
        <div id="content-footer">
            <div class="block-footer">
                <div class="title-block">Contato</div>
                <div class="description-block">Telefone: (31) 99690-5648<br>
                    Email: EletroTechSolutions@contato.com</div>
            </div>
            <div class="block-footer">
                <div class="title-block">Endereço</div>
                <div class="description-block">R. Rio de Janeiro, 471 - Centro, Belo Horizonte - MG, 30160-440</div>
            </div>
        </div>
    </section>

</body>
</html>