<?php 

class ClienteDao {

    public function checkplano($id) {

        try {

            $cliente = new Cliente();
            
            $sql = "SELECT * FROM cliente WHERE idCliente = $id";
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();

            foreach ($lista as $linha) {
                $list[] = $this->listaCliente($linha);
                foreach ($list as $cliente) {
                    $func = $cliente->getPlano();
                }
            }

            if ($func == "Premium Black" || $func == "Premium Basic" || $func == "Free") {
                return true;
            } else {
                echo "<script>
                        alert('Você precisa de um plano para marcar um agendamento')
                      </script>";
                header('Location: ../plano/planos.php');
                return false;
            }
            
        } catch (PDOException $e) {
            echo "Erro ao buscar Cliente <br>" . $e->getMessage();
        }

    }

    public function checkfree($id) {

        try {

            $cliente = new Cliente();
            
            $sql = "SELECT * FROM cliente WHERE idCliente = $id";
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();

            foreach ($lista as $linha) {
                $list[] = $this->listaCliente($linha);
                foreach ($list as $cliente) {
                    $func = $cliente->getPlano();
                }
            }

            if ($func == "Free") {
                return true;
            } else {
                return false;
            }
            
        } catch (PDOException $e) {
            echo "Erro ao buscar Cliente <br>" . $e->getMessage();
        }

    }

    public function addplano($id, $plano) {
        try {
            
            $sql = "UPDATE cliente SET plano = :plano WHERE idCliente = $id";
            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":plano", $plano, PDO::PARAM_STR);
            echo "<script>
                      alert('Plano Escolhido com Sucesso!!');
                  </script>";
            return $stmt->execute();
            
        } catch (PDOException $e) {
            echo "Erro ao adicionar plano <br>" . $e->getMessage();
        }
    }

    public function criar(Cliente $cliente) {

        try {
            
            $sql = "INSERT INTO cliente (nome, cpf, telefone, email, 
            rua, bairro, cidade, estado, numero, complemento, senha) 
            VALUES (:nome, :cpf, :telefone, :email, :rua,
            :bairro, :cidade, :estado, :numero, :complemento, :senha)";

            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":nome", $cliente->getNome(), PDO::PARAM_STR);
            $stmt->bindValue(":cpf", $cliente->getCpf(), PDO::PARAM_STR);
            $stmt->bindValue(":telefone", $cliente->getTelefone(), PDO::PARAM_STR);
            $stmt->bindValue(":email", $cliente->getEmail(), PDO::PARAM_STR);
            $stmt->bindValue(":rua", $cliente->getRua(), PDO::PARAM_STR);
            $stmt->bindValue(":bairro", $cliente->getBairro(), PDO::PARAM_STR);
            $stmt->bindValue(":cidade", $cliente->getCidade(), PDO::PARAM_STR);
            $stmt->bindValue(":estado", $cliente->getEstado(), PDO::PARAM_STR);
            $stmt->bindValue(":numero", $cliente->getNumero(), PDO::PARAM_INT);
            $stmt->bindValue(":complemento", $cliente->getComplemento(), PDO::PARAM_STR);
            $stmt->bindValue(":senha", $cliente->getSenha(), PDO::PARAM_STR);

            return $stmt->execute();
            
        } catch (PDOException $e) {
            echo "Erro ao criar Cliente! <br>" . $e->getMessage();
        }
        
    }

    function alterar(Cliente $cliente) {

        try {

            $sql = "UPDATE cliente SET nome = :nome, cpf = :cpf, telefone = :telefone, email = :email, rua = :rua, bairro = :bairro, cidade = :cidade, estado = :estado, numero = :numero, complemento = :complemento, senha = :senha WHERE idCliente = :id";
    
            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":id", $cliente->getId(), PDO::PARAM_INT);
            $stmt->bindValue(":nome", $cliente->getNome(), PDO::PARAM_STR);
            $stmt->bindValue(":cpf", $cliente->getCpf(), PDO::PARAM_STR);
            $stmt->bindValue(":telefone", $cliente->getTelefone(), PDO::PARAM_STR);
            $stmt->bindValue(":email", $cliente->getEmail(), PDO::PARAM_STR);
            $stmt->bindValue(":rua", $cliente->getRua(), PDO::PARAM_STR);
            $stmt->bindValue(":bairro", $cliente->getBairro(), PDO::PARAM_STR);
            $stmt->bindValue(":cidade", $cliente->getCidade(), PDO::PARAM_STR);
            $stmt->bindValue(":estado", $cliente->getEstado(), PDO::PARAM_STR);
            $stmt->bindValue(":numero", $cliente->getNumero(), PDO::PARAM_INT);
            $stmt->bindValue(":complemento", $cliente->getComplemento(), PDO::PARAM_STR);
            $stmt->bindValue(":senha", $cliente->getSenha(), PDO::PARAM_STR);

            echo "<script>
                      alert('Cliente Alterado com Sucesso!!');
                  </script>";

            return $stmt->execute();
    
        } catch (PDOException $e) {
            echo "Erro ao atualizar dados <br>" . $e->getMessage();
        }

    }

    public function listar($id) {
        try {
            
            $sql = "SELECT * FROM cliente WHERE idCliente = $id";
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();

            foreach ($lista as $linha) {
                $list[] = $this->listaCliente($linha);
            }

            return $list;
            
        } catch (PDOException $e) {
            echo "Erro ao buscar Cliente <br>" . $e->getMessage();
        }
    }

    private function listaCliente($linhas) {

        $cliente = new Cliente();
        $cliente->setId($linhas['idCliente']);
        $cliente->setNome($linhas['nome']);
        $cliente->setCpf($linhas['cpf']);
        $cliente->setTelefone($linhas['telefone']);
        $cliente->setEmail($linhas['email']);
        $cliente->setRua($linhas['rua']);
        $cliente->setBairro($linhas['bairro']);
        $cliente->setCidade($linhas['cidade']);
        $cliente->setEstado($linhas['estado']);
        $cliente->setNumero($linhas['numero']);
        $cliente->setComplemento($linhas['complemento']);
        $cliente->setPlano($linhas['plano']);
        $cliente->setSenha($linhas['senha']);

        return $cliente;

    }

    public function excluir(Cliente $cliente) {

        try {

            $this->excluiragendamento($cliente);
            
            $sql = "DELETE FROM cliente WHERE idCliente = :id";
            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":id", $cliente->getId(), PDO::PARAM_INT);
                
            return $stmt->execute();

        } catch (PDOException $e) {
            echo "Erro ao deletar Cliente! <br>" . $e->getMessage();
        }

    }

    public function excluiragendamento(Cliente $cliente) {
        try {
            
            $sql = "DELETE FROM agendamento WHERE idCliente = :id";
            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":id", $cliente->getId(), PDO::PARAM_INT);
                
            return $stmt->execute();
            
        } catch (PDOException $e) {
            echo "Erro ao excluir agendamentos <br>" . $e->getMessage();
        }
    }

    public function login(Cliente $cliente) {
		try {
			$sql = "SELECT * FROM cliente WHERE email = :email";
			$stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":email", $cliente->getEmail(), PDO::PARAM_STR);
            $stmt->execute();
			$user_linha = $stmt->fetch(PDO::FETCH_ASSOC);
					
			if($stmt->rowCount() == 1) {

				if($cliente->getSenha() == $user_linha['senha']) {

					$_SESSION['user_session'] = $user_linha['idCliente'];
                    session_start();
					return true;
                    
				} else {
					return false;
				}
			}
		}
		catch(PDOException $e) {

			echo "Erro ao tentar realizar o login do usuario" . $e->getMessage();
		}
	}

    public function checkLogin() {
		if(isset($_SESSION['user_session'])) {
			return true;
		}else {
            return false;
        }
	}

    public function logout() {
        session_start();
		session_destroy();
		unset($_SESSION['user_session']);
        header('Location: ../');
		return true;
	}

}

?>