<?php 

class AgendamentoDao {

    public function listar($id) {
        try {
            
            $sql = "SELECT * FROM agendamento WHERE idCliente = $id";
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();

            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
            }

            return $list;
            
        } catch (PDOException $e) {
            echo "Erro ao buscar Agendamentos <br>" . $e->getMessage();
        }
    }

    function horariosvagos_8() {

        try {

            $agendamento = new Agendamento();

            $sql = "SELECT idFuncionario, COUNT(horario), tipo AS horario FROM agendamento WHERE horario = 8";
    
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();
    
            $func = 0;
    
            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
                foreach ($list as $agendamento) {
                    $func = $agendamento->getHorario();
                }
            }

            if ($func == 5) {
                $msg = "Cheio";
            } else {
                $msg = "Disponível";
            }

            return $msg;
    
        } catch (PDOException $e) {
            echo "Erro ao buscar Horário Vago <br>" . $e->getMessage();
        } 
    }

    function horariosvagos_10() {

        try {

            $agendamento = new Agendamento();

            $sql = "SELECT idFuncionario, COUNT(horario), tipo AS horario FROM agendamento WHERE horario = 10";
    
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();
    
            $func = 0;
    
            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
                foreach ($list as $agendamento) {
                    $func = $agendamento->getHorario();
                }
            }

            if ($func == 5) {
                $msg = "Cheio";
            } else {
                $msg = "Disponível";
            }

            return $msg;
    
        } catch (PDOException $e) {
            echo "Erro ao buscar Horário Vago <br>" . $e->getMessage();
        } 
    }

    function horariosvagos_14() {

        try {

            $agendamento = new Agendamento();

            $sql = "SELECT idFuncionario, COUNT(horario), tipo AS horario FROM agendamento WHERE horario = 14";
    
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();
    
            $func = 0;
    
            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
                foreach ($list as $agendamento) {
                    $func = $agendamento->getHorario();
                }
            }

            if ($func == 5) {
                $msg = "Cheio";
            } else {
                $msg = "Disponível";
            }

            return $msg;
    
        } catch (PDOException $e) {
            echo "Erro ao buscar Horário Vago <br>" . $e->getMessage();
        } 
    }

    function horariosvagos_16() {

        try {

            $agendamento = new Agendamento();

            $sql = "SELECT idFuncionario, COUNT(horario), tipo AS horario FROM agendamento WHERE horario = 16";
    
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();
    
            $func = 0;
    
            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
                foreach ($list as $agendamento) {
                    $func = $agendamento->getHorario();
                }
            }

            if ($func == 5) {
                $msg = "Cheio";
            } else {
                $msg = "Disponível";
            }

            return $msg;
    
        } catch (PDOException $e) {
            echo "Erro ao buscar Horário Vago <br>" . $e->getMessage();
        } 
    }

    function criar(Agendamento $agendamento) {
        try {
            
            $sql = "INSERT INTO agendamento (idcliente, idfuncionario, horario, tipo) VALUES (:idcliente, :idfuncionario, :horario, :tipo)";

            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":idcliente", $agendamento->getIdCliente(), PDO::PARAM_INT);
            $stmt->bindValue(":idfuncionario", $this->busca($agendamento->getHorario()), PDO::PARAM_INT);
            $stmt->bindValue(":horario", $agendamento->getHorario(), PDO::PARAM_INT);
            $stmt->bindValue(":tipo", $agendamento->getTipo(), PDO::PARAM_STR);

            return $stmt->execute();

            // echo "Agendamento marcado com sucesso!";
            
        } catch (PDOException $e) {
            echo "Erro ao inserir Agendamento <br>" . $e->getMessage() . "<br>";
        }        
    }

    function busca($horario) {

        try {

            $agendamento = new Agendamento();

            $sql = "SELECT * FROM agendamento WHERE horario != $horario";
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();

            $func = 0;

            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
                foreach ($list as $agendamento) {
                    $func = $agendamento->getIdFuncionario();
                }
            }

            $teste = 0;

            for ($i = 1; $i < 6; $i++) {
                if ($i == $func) {
                    $teste = $func;
                }
            }

            if ($teste == 0) {
                $teste = $this->busca2($horario);
                $func = $teste;
            }

            return $func;

        } catch (PDOException $e) {
            echo "Erro ao buscar Horário Vago <br>" . $e->getMessage();
        }             

    }

    function busca2($horario) {

        try {

            $agendamento = new Agendamento();

            $sql = "SELECT * FROM agendamento WHERE horario = $horario";
            $stmt = Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $list = array();

            $func = 0;

            foreach ($lista as $linha) {
                $list[] = $this->listaagendamento($linha);
                foreach ($list as $agendamento) {
                    $func = $agendamento->getIdFuncionario();
                }
            }

            $teste = 0;

            for ($i = 1; $i < 6; $i++) {
                if ($i == $func) {
                    $teste = $func;
                }
            }

            if ($teste == 0) {
                $func = 1;
            } else if ($teste == 1) {
                $func = 2;
            } else if ($teste == 2) {
                $func = 3;
            } else if ($teste == 3) {
                $func = 4;
            } else if ($teste == 4) {
                $func = 5;
            }

            return $func;

        } catch (PDOException $e) {
            echo "Erro ao buscar Horário Vago <br>" . $e->getMessage();
        }             

    }

    function listaagendamento($linha) {

        $agendamento = new Agendamento();
        $agendamento->setIdFuncionario($linha['idFuncionario']);
        $agendamento->setHorario($linha['horario']);
        $agendamento->setTipo($linha['tipo']);

        return $agendamento;

    }

}

?>