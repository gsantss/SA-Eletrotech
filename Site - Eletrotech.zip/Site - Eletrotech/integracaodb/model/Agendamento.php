<?php 

class Agendamento {

    private $id;
    private $idcliente;
    private $idfuncionario;
    private $horario;
    private $tipo;

    function getId() {
        return $this->id;
    }

    function setId($id) {
        $this->id = $id;
    }

    function getIdCliente() {
        return $this->idcliente;
    }

    function setIdCliente($idcliente) {
        $this->idcliente = $idcliente;
    }

    function getIdFuncionario() {
        return $this->idfuncionario;
    }

    function setIdFuncionario($idfuncionario) {
        $this->idfuncionario = $idfuncionario;
    }

    function getHorario() {
        return $this->horario;
    }

    function setHorario($horario) {
        $this->horario = $horario;
    }

    function getTipo() {
        return $this->tipo;
    }

    function setTipo($tipo) {
        $this->tipo = $tipo;
    }

}

?>