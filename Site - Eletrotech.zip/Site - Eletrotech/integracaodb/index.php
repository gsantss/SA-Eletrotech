<?php
session_start();

require_once('./config/Conexao.php');
require_once('./dao/AgendamentoDao.php');
require_once('./model/Agendamento.php');
require_once('./dao/ClienteDao.php');
require_once('./model/Cliente.php');

Conexao::getConexao();

$agendamentodao = new AgendamentoDao();
$agendamento = new Agendamento();
$clientedao = new ClienteDao();
$cliente = new Cliente();

$login = new ClienteDao();

if(!$login->checkLogin()) {
    header("Location: views/login");
} else {
    header("Location: views/user");
    //session_destroy();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>