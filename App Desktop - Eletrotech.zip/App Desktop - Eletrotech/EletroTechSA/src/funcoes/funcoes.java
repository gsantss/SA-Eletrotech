/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcoes;


import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import model.Funcionario;
import model.Gerente;

/**
 *
 * @author Aluno_Tarde
 */
public class funcoes {
    
    private String logado;

    public String getLogado() {
        return logado;
    }

    public void setLogado(String logado) {
        this.logado = logado;
    }
    
    public boolean Login(String usuario, String senha) {
                
        Gerente g = new Gerente();
        Funcionario funcionario = new Funcionario();
        
        boolean teste;
        
        String sql = "SELECT email, senha FROM funcionario WHERE email = ? AND senha = ?";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
                        
            pstm.setString(1, usuario);
            pstm.setString(2, senha);
                        
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                funcionario.setEmail(rset.getString("email"));
                funcionario.setSenha(rset.getString("senha"));
                                
            }
            
        } catch (Exception e) {
            
            System.out.println("Usuário ou senha inválidos!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        adm(g);
        
        if ((usuario.equals(g.getUsuario()) && senha.equals(g.getSenha()))) {
            this.logado = "adm";
            teste = true;
        } else if ((usuario.equals(funcionario.getEmail()) && senha.equals(funcionario.getSenha()))){
            this.logado = "user";
            teste = true;
        } else {
            teste = false;
        }
        
        return teste;
        
    }
    
    public void adm(Gerente gerente) {
        
        String sql = "SELECT * FROM gerente;";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                gerente.setUsuario(rset.getString("usuario"));
                gerente.setSenha(rset.getString("senha"));
                                
            }
            
        } catch (Exception e) {
            
            System.out.println("Erro ao listar gerente!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
    }
    
}
