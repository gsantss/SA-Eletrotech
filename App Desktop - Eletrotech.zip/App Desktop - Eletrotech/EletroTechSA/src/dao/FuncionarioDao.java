/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Funcionario;

/**
 *
 * @author Aluno_Tarde
 */
public class FuncionarioDao {
    
    public void criar(Funcionario funcionario) {
        
        String sql = "INSERT INTO funcionario(nome, cpf, email, telefone, senha) VALUES(?, ?, ?, ?, ?)";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            pstm.setString(1, funcionario.getNome());
            pstm.setString(2, funcionario.getCpf());
            pstm.setString(3, funcionario.getEmail());
            pstm.setString(4, funcionario.getTelefone());
            pstm.setString(5, funcionario.getSenha());
            
            pstm.execute();
            
            System.out.println("Funcionario cadastrado com sucesso!");
            
        } catch (Exception e) {
            System.out.println("Não foi possivel cadastrar o Funcionario!");
            e.printStackTrace();
        } finally {
            
            try {
                if (pstm != null){
                    pstm.close();
                }
                
                if (conn != null){
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
    }   
    
    public List<Funcionario> ListarFuncionarios() {
        
        String sql = "SELECT * FROM funcionario";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        // Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                Funcionario funcionario = new Funcionario();
                
                
                funcionario.setId(rset.getInt("idfuncionario"));
                funcionario.setNome(rset.getString("nome"));
                funcionario.setCpf(rset.getString("cpf"));
                funcionario.setEmail(rset.getString("email"));
                funcionario.setTelefone(rset.getString("telefone"));
                funcionario.setSenha(rset.getString("senha"));
                
                funcionarios.add(funcionario);
                
            }
            
        } catch (Exception e) {
            
            System.out.println("Erro ao listar os funcionarios!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        return funcionarios;
        
    } 
    
    public List<Funcionario> ListarFuncionario(int id) {
        
        String sql = "SELECT * FROM funcionario WHERE idfuncionario = ?";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        // Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            pstm.setInt(1, id);
            pstm.execute();
            
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                Funcionario funcionario = new Funcionario();
                
                
                funcionario.setId(rset.getInt("idfuncionario"));
                funcionario.setNome(rset.getString("nome"));
                funcionario.setCpf(rset.getString("cpf"));
                funcionario.setEmail(rset.getString("email"));
                funcionario.setTelefone(rset.getString("telefone"));
                funcionario.setSenha(rset.getString("senha"));
                
                funcionarios.add(funcionario);
                
            }
            
        } catch (Exception e) {
            
            System.out.println("Erro ao listar os funcionarios!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        return funcionarios;
        
    }
    
    public void alterar(Funcionario funcionario){
        
        String sql = "UPDATE funcionario SET nome = ?, cpf = ?, email = ?, telefone = ?, senha = ? WHERE idfuncionario = ?";
        
        Connection conn = null;
        PreparedStatement pstm  = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            // Adcione os registros que serão atualizados
            
            pstm.setString(1,funcionario.getNome());
            pstm.setString(2,funcionario.getCpf());
            pstm.setString(3,funcionario.getEmail());
            pstm.setString(4,funcionario.getTelefone());
            pstm.setString(5,funcionario.getSenha());
            
            // Recebe qual ID do veículo deseja alterar
            
            pstm.setInt(6, funcionario.getId());
            
            // Executar a query
            pstm.execute();
            
            
            System.out.println("Funcionario atualizado com sucesso");
            
        } catch (Exception e) {
            
            System.out.println("Erro ao tentar atualizar o funcionario");
            e.printStackTrace();
            
        } finally{
            
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                
            } catch (Exception e) {
            
                e.printStackTrace();
            
            }
            
        }
        
        
    }
    
    public void excluir(int id) {
        
        String sql = "DELETE FROM funcionario WHERE idfuncionario = ?";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            pstm.setInt(1, id);
            pstm.execute();
            
            System.out.println("Funcionario excluido com sucesso!");
            
        } catch (Exception e) {
            
            System.out.println("Erro ao excluir o funcionario");
            e.printStackTrace();
            
        } finally {
            
            try {
                
              if (pstm != null) { pstm.close(); }
              if (conn != null) { conn.close(); }
                
            } catch (Exception e) {
            
                e.printStackTrace();
            
            }
        
        }
    
    }
    
}
