/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Agendamento;

/**
 *
 * @author Aluno_Tarde
 */
public class AgendamentoDao {
    
    public List<Agendamento> ListarAgendamentos() {
        
        String sql = "SELECT a.idAgendamento, c.nome as cnome, f.nome as fnome, "
                + "a.horario, a.tipo FROM cliente as c INNER JOIN agendamento as a "
                + "ON a.idCliente = c.idCliente INNER JOIN funcionario as f "
                + "ON a.idFuncionario = f.idFuncionario ORDER BY a.horario;";
        
        List<Agendamento> agendamentos = new ArrayList<Agendamento>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        // Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                Agendamento agendamento = new Agendamento();
                
                
                agendamento.setId(rset.getInt("idagendamento"));
                agendamento.setCliente(rset.getString("cnome"));
                agendamento.setFuncionario(rset.getString("fnome"));
                agendamento.setHorario(rset.getString("horario"));
                agendamento.setTipo(rset.getString("tipo"));
                
                agendamentos.add(agendamento);
                
            }
            
        } catch (Exception e) {
            
            System.out.println("Erro ao listar os agendamentos!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        return agendamentos;
        
    }
    
    public List<Agendamento> AgendamentosDia() {
        
        String sql = "SELECT a.idAgendamento, c.nome as cnome, f.nome as fnome, a.horario, "
                + "a.tipo, c.rua, c.numero, c.bairro, c.cidade, c.estado FROM cliente as c "
                + "INNER JOIN agendamento as a ON a.idCliente = c.idCliente "
                + "INNER JOIN funcionario as f ON a.idFuncionario = f.idFuncionario "
                + "ORDER BY a.horario;";
        
        List<Agendamento> agendamentos = new ArrayList<Agendamento>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        // Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                Agendamento agendamento = new Agendamento();
                
                String rua = rset.getString("rua");
                String numero = String.valueOf(rset.getInt("numero"));
                String bairro = rset.getString("bairro");
                String cidade = rset.getString("cidade");
                String estado = rset.getString("estado");
                String endereco = rua + ", " + numero + " - Bairro: " + bairro + " - " + cidade + " - " + estado;
                
                agendamento.setId(rset.getInt("idagendamento"));
                agendamento.setCliente(rset.getString("cnome"));
                agendamento.setFuncionario(rset.getString("fnome"));
                agendamento.setHorario(rset.getString("horario"));
                agendamento.setTipo(rset.getString("tipo"));
                agendamento.setEndereco(endereco);
                
                agendamentos.add(agendamento);
                
            }
            
        } catch (Exception e) {
            
            System.out.println("Erro ao listar os agendamentos!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        return agendamentos;
        
    }
    
    public List<Agendamento> ListarCod(int id) {
        
        String sql = "SELECT a.idAgendamento, c.nome as cnome, f.nome as fnome, a.horario,"
                + "a.tipo FROM cliente as c INNER JOIN agendamento as a ON a.idCliente = c.idCliente "
                + "INNER JOIN funcionario as f ON a.idFuncionario = f.idFuncionario "
                + "WHERE a.idAgendamento = ? ORDER BY a.horario;";
        
        List<Agendamento> agendamentos = new ArrayList<Agendamento>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        // Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            pstm.setInt(1, id);
            pstm.execute();
            
            rset = pstm.executeQuery();
            
            while (rset.next()) {
                
                Agendamento agendamento = new Agendamento();
                
                // Recuperar dados de cada coluna no banco de dados
                agendamento.setId(rset.getInt("idagendamento"));
                agendamento.setCliente(rset.getString("cnome"));
                agendamento.setFuncionario(rset.getString("fnome"));
                agendamento.setHorario(rset.getString("horario"));
                agendamento.setTipo(rset.getString("tipo"));
                
                agendamentos.add(agendamento);
                
                
            }
            
        } catch (Exception e) {
            
            System.out.println("Erro ao listar o veiculo!!");
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                if (rset != null) { rset.close(); }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
        return agendamentos;
        
    }
    
}
