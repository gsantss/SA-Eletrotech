/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Gerente;

/**
 *
 * @author Aluno_Tarde
 */
public class GerenteDao {
    
    public void alterar(Gerente gerente){
        
        String sql = "UPDATE gerente SET usuario = ?, senha = ?";
        
        Connection conn = null;
        PreparedStatement pstm  = null;
        
        try {
            
            conn = Conexao.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            // Adcione os registros que serão atualizados
            
            pstm.setString(1,gerente.getUsuario());
            pstm.setString(2,gerente.getSenha());
            
            // Executar a query
            pstm.execute();
            
            
            System.out.println("Gerente atualizado com sucesso");
            
        } catch (Exception e) {
            
            System.out.println("Erro ao tentar atualizar o gerente");
            e.printStackTrace();
            
        } finally{
            
            
            try {
                
                if (pstm != null) { pstm.close(); }
                if (conn != null) { conn.close(); }
                
            } catch (Exception e) {
            
                e.printStackTrace();
            
            }
            
        }
        
        
    }
    
}
