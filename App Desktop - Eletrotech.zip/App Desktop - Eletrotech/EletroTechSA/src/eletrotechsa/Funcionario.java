/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eletrotechsa;

/**
 *
 * @author Aluno_Tarde
 */
public class Funcionario {
    private String emailFunc;
    private String senhaFunc;
    private String nomeFunc;
    private String telefoneFunc;
    private String CPFFunc;

    
    
    public Funcionario(String emailFunc, String senhaFunc, String nomeFunc, String telefoneFunc, String CPFFunc){
        this.emailFunc = emailFunc;
        this.senhaFunc = senhaFunc;
        this.nomeFunc = nomeFunc;
        this.telefoneFunc = telefoneFunc;
        this.CPFFunc = CPFFunc;
    }

    public String getEmailFunc() {
        return emailFunc;
    }

    public void setEmailFunc(String emailFunc) {
        this.emailFunc = emailFunc;
    }

    public String getSenhaFunc() {
        return senhaFunc;
    }

    public void setSenhaFunc(String senhaFunc) {
        this.senhaFunc = senhaFunc;
    }

    public String getNomeFunc() {
        return nomeFunc;
    }

    public void setNomeFunc(String nomeFunc) {
        this.nomeFunc = nomeFunc;
    }

    public String getTelefoneFunc() {
        return telefoneFunc;
    }

    public void setTelefoneFunc(String telefoneFunc) {
        this.telefoneFunc = telefoneFunc;
    }

    public String getCPFFunc() {
        return CPFFunc;
    }

    public void setCPFFunc(String CPFFunc) {
        this.CPFFunc = CPFFunc;
    }

    
}
