/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eletrotechsa;

/**
 *
 * @author gf221
 */
public class Administrador {
    private String emailAdm;
    private String senhaAdm;
    
    public Administrador (String emailAdm, String senhaAdm){
        this.emailAdm = emailAdm;
        this.senhaAdm = senhaAdm;
    }

    public String getEmailAdm() {
        return emailAdm;
    }

    public void setEmailAdm(String emailAdm) {
        this.emailAdm = emailAdm;
    }

    public String getSenhaAdm() {
        return senhaAdm;
    }

    public void setSenhaAdm(String senhaAdm) {
        this.senhaAdm = senhaAdm;
    }
}
