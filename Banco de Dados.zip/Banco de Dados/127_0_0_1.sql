-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 02-Fev-2023 às 15:53
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `eletrotech`
--
CREATE DATABASE IF NOT EXISTS `eletrotech` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `eletrotech`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `agendamento`
--

CREATE TABLE `agendamento` (
  `idCliente` int(11) NOT NULL,
  `idFuncionario` int(11) NOT NULL,
  `idAgendamento` int(11) NOT NULL,
  `horario` int(11) NOT NULL,
  `tipo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Extraindo dados da tabela `agendamento`
--

INSERT INTO `agendamento` (`idCliente`, `idFuncionario`, `idAgendamento`, `horario`, `tipo`) VALUES
(1, 4, 1, 8, 'Manutenção'),
(2, 5, 2, 16, 'Manutenção');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `telefone` varchar(14) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rua` varchar(40) NOT NULL,
  `bairro` varchar(30) NOT NULL,
  `cidade` varchar(30) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `numero` int(11) NOT NULL,
  `complemento` varchar(20) DEFAULT NULL,
  `plano` varchar(30) DEFAULT NULL,
  `senha` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nome`, `cpf`, `telefone`, `email`, `rua`, `bairro`, `cidade`, `estado`, `numero`, `complemento`, `plano`, `senha`) VALUES
(1, 'Wellington Pereira Santos', '165.465.384-46', '(31)98642-6846', 'well@gmail.com', 'Rua dos Mestres', 'Lendas', 'Belo Horizonte', 'Minas Gerais', 112, 'Casa', 'Premium Black', '12345'),
(2, 'Leonardo Guedes Gomes Junior', '646.486.354-22', '(31)98451-7486', 'leleo@gmail.com', 'Rua dos Viciados', 'Fifa', 'Belo Horizonte', 'Minas Gerais', 220, 'Apartamento 3B', 'Premium Basic', '12345'),
(4, 'Cleiton Rocha Silva', '018.350.272-90', '(31)98354-6465', 'cleitin@gmail.com', 'Rua da Bahia', 'Nova Pampulha', 'Belo Horizonte', 'Minas Gerais', 127, '', 'Free', '12345');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `idFuncionario` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefone` varchar(14) NOT NULL,
  `senha` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`idFuncionario`, `nome`, `cpf`, `email`, `telefone`, `senha`) VALUES
(1, 'Andre Santos Martins da Silva', '018.350.286-83', 'dede@gmail.com', '(31)98222-2535', '12345'),
(2, 'Gabriel Felipe Santos de Sousa', '042.315.715-24', 'gabriel@gmail.com', '(31)98468-6467', '12345'),
(3, 'Patrick de Souza Lima', '164.275.346-15', 'adaonegro@gmail.com', '(31)99654-6468', '12345'),
(4, 'Rafael Alves dos Santos', '644.642.216-34', 'alves@gmail.com', '(31)99513-7436', '12345'),
(5, 'Jessica Alves Marinho', '646.344.761-11', 'jessica@gmail.com', '(31)99463-2113', '12345');

-- --------------------------------------------------------

--
-- Estrutura da tabela `gerente`
--

CREATE TABLE `gerente` (
  `usuario` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Extraindo dados da tabela `gerente`
--

INSERT INTO `gerente` (`usuario`, `senha`) VALUES
('admin@gmail.com', 'admin');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `agendamento`
--
ALTER TABLE `agendamento`
  ADD PRIMARY KEY (`idAgendamento`),
  ADD UNIQUE KEY `idAgendamento_UNIQUE` (`idAgendamento`),
  ADD KEY `fk_cliente_has_funcionario_funcionario1_idx` (`idFuncionario`),
  ADD KEY `fk_cliente_has_funcionario_cliente_idx` (`idCliente`);

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`),
  ADD UNIQUE KEY `idCliente_UNIQUE` (`idCliente`),
  ADD UNIQUE KEY `cpf_UNIQUE` (`cpf`);

--
-- Índices para tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`idFuncionario`),
  ADD UNIQUE KEY `idFuncionario_UNIQUE` (`idFuncionario`),
  ADD UNIQUE KEY `cpf_UNIQUE` (`cpf`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamento`
--
ALTER TABLE `agendamento`
  MODIFY `idAgendamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `idFuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `agendamento`
--
ALTER TABLE `agendamento`
  ADD CONSTRAINT `fk_cliente_has_funcionario_cliente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cliente_has_funcionario_funcionario1` FOREIGN KEY (`idFuncionario`) REFERENCES `funcionario` (`idFuncionario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
